import logo from './logo.svg';
import './App.css';
import Nav from "./Nav.js"
import Dash from "./Dashboard.js"
function App() {
  return (
   <>
   <Nav/>
   <Dash/>
   </>
  );
}

export default App;
